import sys,os

f = open('neg_train','rb')
file = open('neg_train_extracted','wb')

for line in f:
	line2 = line.split(b',')
	line3 = line2[-1]
	line4 = line3.replace(b'\r',b'')
	line5 = line4.replace(b'\n',b'')
	line5 = line5.replace(b'A',b'1 0 0 0 ')
	line5 = line5.replace(b'T',b'0 1 0 0 ')
	line5 = line5.replace(b'C',b'0 0 1 0 ')
	line5 = line5.replace(b'G',b'0 0 0 1 ')
	line5 = line5.replace(b'N',b'0 0 0 0 ')
	file.write(line5 + b'\r\n')

f.close()
file.close()