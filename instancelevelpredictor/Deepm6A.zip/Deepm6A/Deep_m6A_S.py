#coding=utf-8
import numpy as np


import tensorflow as tf
from tensorflow import keras
config = tf.ConfigProto()
config.gpu_options.allow_growth = True 
sess = tf.Session(config = config) 
keras.backend.set_session(sess)
# numpy.loadtxt默认载入浮点数据

#测试样本载入
train_sequence_p = np.loadtxt('./ARAdataset/pos_train_extracted')
train_sequence_n = np.loadtxt('./ARAdataset/neg_train_extracted')
np.random.shuffle(train_sequence_p)
np.random.shuffle(train_sequence_n)

train_sequence = np.concatenate((train_sequence_p,train_sequence_n))
train_label_p = np.ones((len(train_sequence_p),))
train_label_n = np.zeros((len(train_sequence_n),))
train_label = np.concatenate((train_label_p,train_label_n))

# 测试样本载入
test_sequence_p = np.loadtxt('./ARAdataset/pos_test_extracted')
test_sequence_n = np.loadtxt('./ARAdataset/neg_test_extracted')

test_sequence = np.concatenate((test_sequence_p,test_sequence_n))
test_label_p = np.ones((len(test_sequence_p),))
test_label_n = np.zeros((len(test_sequence_n),))
test_label = np.concatenate((test_label_p,test_label_n))


# 将数据转化为3维张量形式（对应2维卷积神经网络）
train_sequence = train_sequence.reshape(len(train_sequence),41,4,1)
test_sequence = test_sequence.reshape(len(test_sequence),41,4,1)


def build_model():
	network = models.Sequential()
	# network.add(layers.Embedding(4,128,input_length = 51))
	network.add(layers.Conv2D(32, (5,4), activation = 'relu', input_shape = (41, 4,1)))
	network.add(layers.MaxPooling2D((4,1)))
	network.add(layers.Flatten())
	network.add(layers.Dropout(0.25))
	network.add(layers.Dense(12,activation = 'relu'))
	network.add(layers.Dropout(0.25))
	network.add(layers.Dense(1,activation='sigmoid'))
	# network.compile(optimizer = 'Adadelta',loss = 'binary_crossentropy',metrics = ['accuracy'])
	network.compile(optimizer = 'Adam',loss = 'binary_crossentropy',metrics = ['accuracy'])
	return network


from keras.callbacks import Callback
from sklearn.metrics import f1_score, recall_score, precision_score, roc_auc_score

# 为Keras单独实现的Callback函数，利用scikit-learn提供的函数计算precision，recall，F1，ROC AUC
class Metrics(Callback):
	def on_train_begin(self, logs={}):
		self.val_f1s = []
		self.val_recalls = []
		self.val_precisions = []
		self.val_auc = []
		
	def on_epoch_end(self, epoch, logs={}):
		val_predict = (np.asarray(self.model.predict(self.validation_data[0]))).round()
		val_target = self.validation_data[1]
		_val_f1 = f1_score(val_target, val_predict)
		_val_recall = recall_score(val_target, val_predict)
		_val_precision = precision_score(val_target, val_predict)
		val_predict1 = (np.asarray(self.model.predict_proba(self.validation_data[0])))
		_val_auc = roc_auc_score(val_target,val_predict1)
		self.val_f1s.append(_val_f1)
		self.val_recalls.append(_val_recall)
		self.val_precisions.append(_val_precision)
		self.val_auc.append(_val_auc)

metrics_here = Metrics()

from keras import models
from keras import layers
# from keras.layers import Embedding, SimpleRNN
from keras import regularizers
from keras.optimizers import SGD

# 建立模型
model = build_model()

# 训练模型
model.fit(train_sequence, train_label, epochs = 25, batch_size = 64, validation_data = (test_sequence, test_label), callbacks = [metrics_here])

# 打印训练结果
print('Val_f1s: ',metrics_here.val_f1s)
print('Val_precisions: ', metrics_here.val_precisions)
print('Val_recalls: ', metrics_here.val_recalls)
print('Val_roc_auc: ', metrics_here.val_auc)

pred_proba = model.predict_proba(test_sequence)
print('Probability: ', pred_proba)

# 将预测的概率值保存在名为pred_proba_file的文件中
np.savetxt('pred_proba_file',pred_proba, fmt='%.4f')

# 保存训练得到的神经网络
model.save('Deep_m6A_S.h5')



